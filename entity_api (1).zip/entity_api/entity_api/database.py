"""
=====================================================
DATABASE LAYER
=====================================================
Solely responsible for the SQLite connection and table
schema creation. Other modules should never call
sqlite3.connect() directly, just use get_connection().
"""

import sqlite3

from .config import DB_NAME


def get_connection() -> sqlite3.Connection:
    """Open a new connection to the SQLite database."""
    return sqlite3.connect(DB_NAME)


def initialize_database() -> None:
    """Create the 'entities' table if it doesn't exist yet."""
    conn = get_connection()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_hash TEXT UNIQUE,
                systemCode TEXT,
                businessEntityCode TEXT,
                EOID TEXT,
                FID TEXT,
                UKEOID TEXT,
                UKFID TEXT,
                SGLN TEXT,
                entity_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()
    finally:
        conn.close()
