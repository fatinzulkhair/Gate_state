"""
=====================================================
CRUD / BUSINESS LOGIC LAYER
=====================================================
All read/write operations on the 'entities' table, plus the
logic for processing a payload (list of entities), live here.
Endpoints (routers) only call these functions and never touch
sqlite3 directly.
"""

import json

import pandas as pd
from fastapi import HTTPException

from .database import get_connection
from .hashing import generate_entity_hash


# ---------------------------------------------------
# INSERT A SINGLE ENTITY
# ---------------------------------------------------

def insert_entity(entity: dict) -> dict:
    entity_hash = generate_entity_hash(entity)

    conn = get_connection()
    try:
        cursor = conn.cursor()

        cursor.execute(
            "SELECT id FROM entities WHERE entity_hash = ?",
            (entity_hash,),
        )
        existing = cursor.fetchone()

        if existing:
            return {
                "status": "skipped",
                "reason": "already_exists",
                "businessEntityCode": entity.get("businessEntityCode"),
                "existing_id": existing[0],
            }

        cursor.execute(
            """
            INSERT INTO entities
            (
                entity_hash, systemCode, businessEntityCode,
                EOID, FID, UKEOID, UKFID, SGLN, entity_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                entity_hash,
                entity.get("systemCode"),
                entity.get("businessEntityCode"),
                entity.get("EOID"),
                entity.get("FID"),
                entity.get("UKEOID"),
                entity.get("UKFID"),
                entity.get("SGLN"),
                json.dumps(entity),
            ),
        )

        conn.commit()
        inserted_id = cursor.lastrowid

        return {
            "status": "inserted",
            "id": inserted_id,
            "businessEntityCode": entity.get("businessEntityCode"),
        }
    finally:
        conn.close()


# ---------------------------------------------------
# PROCESS PAYLOAD (list of entities inside "mappingsInformation",
# or a single entity sent directly)
# ---------------------------------------------------

def process_payload(payload: dict) -> dict:
    if "mappingsInformation" in payload:
        mappings = payload.get("mappingsInformation", [])

        if not isinstance(mappings, list):
            raise HTTPException(
                status_code=400,
                detail="Field 'mappingsInformation' must be a list/array",
            )
    else:
        mappings = [payload]

    results = []
    inserted_count = 0
    skipped_count = 0

    for entity in mappings:
        result = insert_entity(entity)
        results.append(result)

        if result["status"] == "inserted":
            inserted_count += 1
        else:
            skipped_count += 1

    return {
        "total_entities": len(mappings),
        "inserted": inserted_count,
        "skipped": skipped_count,
        "details": results,
    }


# ---------------------------------------------------
# QUERY HELPERS
# ---------------------------------------------------

def get_all_entities() -> pd.DataFrame:
    conn = get_connection()
    try:
        df = pd.read_sql_query(
            """
            SELECT id, businessEntityCode, EOID, FID, UKEOID, UKFID, created_at
            FROM entities
            ORDER BY id
            """,
            conn,
        )
        return df
    finally:
        conn.close()


def find_entity_by_code(business_entity_code: str) -> pd.DataFrame:
    conn = get_connection()
    try:
        df = pd.read_sql_query(
            "SELECT * FROM entities WHERE businessEntityCode = ?",
            conn,
            params=(business_entity_code,),
        )
        return df
    finally:
        conn.close()
