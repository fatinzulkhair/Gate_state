"""
validation.py
==============
Table-driven data validation module, built on 2 tables (Rules + Rule
Conditions).

STRUCTURE
---------
TABLE 1 - RULES (header, one row = one rule)
    Rule ID, Validation Type, Function Name (optional, only for custom
    logic), Description, Severity, Active, On Exception Status,
    On Exception Description

TABLE 2 - RULE_CONDITIONS (detail, many rows per Rule ID)
    Rule ID, Role (Trigger/Target), Field Name, Operator, Expected Value,
    Data Type, Constraint, Reference Source, Logical Group

By default both tables are embedded below as plain Python data so this
module is self-contained. They can also be loaded from a SQLite database
(see load_rules_from_database) once the "rules" and "rule_conditions"
tables have been created and seeded (see the db_setup package).

USAGE
-----
    from validation import Validation

    result = Validation(
        id=1,
        entity_hash="abc123...",
        entity_result={
            "systemCode": "ACDC",
            "businessEntityCode": "SGLN_mapping",
            "EOID": "LEWL1EQwJwW9",
            "FID": "LEWL1Fjwo8Cb",
            "UKEOID": "6025",
            "UKFID": "Zsv77YiBg_oBtXQ",
            "SGLN": "urn:epc:id:sgln:2143135.29114.0",
        },
    )
    print(result)

ADDING A NEW RULE (common case, no code needed)
-------------------------------------------------
    1. Add a new row to RULES_TABLE (with a unique Rule ID).
    2. Add Target rows (and Trigger rows if needed) to
       RULE_CONDITIONS_TABLE with the same Rule ID.
    No need to touch any code below.

ADDING A NEW RULE (custom / complex logic)
---------------------------------------------
    1. Write a new function, register it with @register_validation("FunctionName").
    2. Set the "Function Name" column in RULES_TABLE to that name.
    3. Target rows in RULE_CONDITIONS_TABLE are still used as the list of
       fields that function validates.
"""

from __future__ import annotations

import re
import sqlite3
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple


# =============================================================================
# TABLE 1 - RULES
# =============================================================================
# Active: "Y" the rule runs, "N" the rule is skipped (without deleting it
# from the table)

RULES_TABLE: List[Dict[str, Any]] = [
    {
        "Rule ID": "VAL-001",
        "Validation Type": "Location Master Data – EoId, FID",
        "Function Name": "EoIDFiDValidation",
        "Description": (
            "If the location address is in the EU/UK country, then this is a "
            "mandatory OR if the location would produce for EU/UK Market, then "
            "also it is mandatory for this fields to be present"
        ),
        "Severity": "Critical",
        "Active": "Y",
        "On Exception Status": -1,
        "On Exception Description": "Missing EoID/FiD",
    },
    {
        "Rule ID": "VAL-002",
        "Validation Type": "Conditional Field – ACDC UK mapping",
        "Function Name": "",  # empty -> handled by the generic Trigger/Target engine
        "Description": "UKEOID/UKFID are mandatory when systemCode = ACDC",
        "Severity": "Critical",
        "Active": "Y",
        "On Exception Status": -1,
        "On Exception Description": "Missing UKEOID/UKFID for ACDC",
    },
    {
        "Rule ID": "VAL-003",
        "Validation Type": "SGLN Format Check",
        "Function Name": "",
        "Description": "SGLN must follow the format urn:epc:id:sgln:...",
        "Severity": "Critical",
        "Active": "Y",
        "On Exception Status": -1,
        "On Exception Description": "SGLN format invalid",
    },
    {
        "Rule ID": "VAL-004",
        "Validation Type": "System Code Presence",
        "Function Name": "",
        "Description": "systemCode is mandatory for every record",
        "Severity": "Critical",
        "Active": "Y",
        "On Exception Status": -1,
        "On Exception Description": "Missing systemCode",
    },
    {
        "Rule ID": "VAL-005",
        "Validation Type": "EOID Uniqueness",
        "Function Name": "",
        "Description": "EOID must not duplicate another already-processed record",
        "Severity": "Critical",
        "Active": "Y",
        "On Exception Status": -1,
        "On Exception Description": "Duplicate EOID",
    },
]


# =============================================================================
# TABLE 2 - RULE_CONDITIONS
# =============================================================================
# Role            : "Trigger" (decides when the rule applies) or "Target"
#                   (the field that actually gets checked)
# Operator        : used on Trigger rows -> equals, not_equals, in, not_in,
#                   contains, regex, exists
# Data Type       : used on Target rows -> Exist, Text, Number, Boolean,
#                   Date, Enum, Regex, Romanize, Length, Unique
# Constraint      : extra parameters for the Data Type (see DATA_TYPE_HELP below)
# Reference Source: only for Data Type Unique -> "batch" or "database.<table>.<col>"
# Logical Group   : "AND" / "OR" -> how multiple Trigger rows are combined

RULE_CONDITIONS_TABLE: List[Dict[str, Any]] = [
    # --- VAL-001: EoID/FiD mandatory for EU/UK (the conditional logic lives
    #     in a custom function; the rows here are only used as the list of
    #     target fields) ---
    {"Rule ID": "VAL-001", "Role": "Target", "Field Name": "EOID", "Operator": "",
     "Expected Value": "", "Data Type": "Exist", "Constraint": "",
     "Reference Source": "", "Logical Group": ""},
    {"Rule ID": "VAL-001", "Role": "Target", "Field Name": "FID", "Operator": "",
     "Expected Value": "", "Data Type": "Exist", "Constraint": "",
     "Reference Source": "", "Logical Group": ""},

    # --- VAL-002: if systemCode == ACDC -> UKEOID, UKFID are mandatory ---
    {"Rule ID": "VAL-002", "Role": "Trigger", "Field Name": "systemCode", "Operator": "equals",
     "Expected Value": "ACDC", "Data Type": "", "Constraint": "",
     "Reference Source": "", "Logical Group": "AND"},
    {"Rule ID": "VAL-002", "Role": "Target", "Field Name": "UKEOID", "Operator": "",
     "Expected Value": "", "Data Type": "Exist", "Constraint": "",
     "Reference Source": "", "Logical Group": ""},
    {"Rule ID": "VAL-002", "Role": "Target", "Field Name": "UKFID", "Operator": "",
     "Expected Value": "", "Data Type": "Exist", "Constraint": "",
     "Reference Source": "", "Logical Group": ""},

    # --- VAL-003: SGLN format ---
    {"Rule ID": "VAL-003", "Role": "Target", "Field Name": "SGLN", "Operator": "",
     "Expected Value": "", "Data Type": "Regex", "Constraint": r"^urn:epc:id:sgln:.+$",
     "Reference Source": "", "Logical Group": ""},

    # --- VAL-004: systemCode must be present ---
    {"Rule ID": "VAL-004", "Role": "Target", "Field Name": "systemCode", "Operator": "",
     "Expected Value": "", "Data Type": "Exist", "Constraint": "",
     "Reference Source": "", "Logical Group": ""},

    # --- VAL-005: EOID unique (batch scope: checked across the records
    #     processed within the current running session) ---
    {"Rule ID": "VAL-005", "Role": "Target", "Field Name": "EOID", "Operator": "",
     "Expected Value": "", "Data Type": "Unique", "Constraint": "",
     "Reference Source": "batch", "Logical Group": ""},
]


# Short reference documentation for the Constraint parameters of each Data
# Type (not used by the code itself, just a reference for whoever fills in
# the tables).
DATA_TYPE_HELP = {
    "Exist": "no Constraint needed",
    "Text": "optional: pattern=alpha_only",
    "Number": "optional: type=int|float;min=<n>;max=<n>",
    "Boolean": "no Constraint needed (true/false/Y/N/1/0 all accepted)",
    "Date": "optional: format=%Y-%m-%d (default %Y-%m-%d)",
    "Enum": "comma-separated list of allowed values, e.g. Active,Inactive,Pending",
    "Regex": "a regex pattern, e.g. ^urn:epc:id:sgln:.+$",
    "Romanize": "no Constraint needed (checks that characters are Latin/ASCII)",
    "Length": "min=<n>;max=<n>",
    "Unique": "use the 'Reference Source' column: 'batch' or 'database.<table>.<column>'",
}


# =============================================================================
# REGISTRY FOR CUSTOM FUNCTION NAME
# =============================================================================

CUSTOM_VALIDATION_REGISTRY: Dict[str, Callable] = {}


def register_validation(name: str):
    def decorator(func):
        CUSTOM_VALIDATION_REGISTRY[name] = func
        return func
    return decorator


EU_UK_COUNTRY_CODES = {
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR",
    "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
    "SI", "ES", "SE",  # EU
    "GB", "UK",        # UK
}


def _is_eu_uk(record: dict) -> bool:
    """
    Detect whether this record is relevant to the EU/UK.

    If the data has explicit 'Country'/'Market' fields, that's the correct
    path (checked against EU_UK_COUNTRY_CODES). Since the sample data (the
    ACDC payload) does not have those fields yet, a fallback is used: any
    field starting with 'UK' that has a value (e.g. UKEOID, UKFID) is
    treated as a signal of UK/EU relevance. Replace/extend this logic once
    a real Country/Market field is available in your data.
    """
    country = record.get("Country") or record.get("country")
    market = record.get("Market") or record.get("market")
    if country and str(country).strip().upper() in EU_UK_COUNTRY_CODES:
        return True
    if market and str(market).strip().upper() in EU_UK_COUNTRY_CODES:
        return True

    uk_fields = [k for k in record.keys() if k.upper().startswith("UK")]
    if any(record.get(k) not in (None, "", "null") for k in uk_fields):
        return True

    return False


@register_validation("EoIDFiDValidation")
def _validate_eoid_fid(record: dict, target_fields: List[str], rule: dict) -> Tuple[bool, List[str], str]:
    if not _is_eu_uk(record):
        return True, [], "Not an EU/UK location or market, rule does not apply"
    missing = [f for f in target_fields if not record.get(f)]
    if missing:
        return False, missing, f"Required field(s) missing or empty: {', '.join(missing)}"
    return True, [], "OK"


# =============================================================================
# OPERATOR EVALUATION (for Trigger rows)
# =============================================================================

def _evaluate_operator(actual: Any, operator: str, expected: str) -> bool:
    operator = (operator or "").strip().lower()

    if operator == "exists":
        return actual not in (None, "", [], {})

    if actual is None:
        actual = ""

    if operator == "equals":
        return str(actual).strip() == str(expected).strip()
    if operator == "not_equals":
        return str(actual).strip() != str(expected).strip()
    if operator == "in":
        allowed = [v.strip() for v in str(expected).split(",")]
        return str(actual).strip() in allowed
    if operator == "not_in":
        allowed = [v.strip() for v in str(expected).split(",")]
        return str(actual).strip() not in allowed
    if operator == "contains":
        return str(expected) in str(actual)
    if operator == "regex":
        return bool(re.match(str(expected), str(actual)))

    raise ValueError(f"Unknown operator: '{operator}'")


# =============================================================================
# DATA TYPE CHECK (for Target rows)
# =============================================================================

def _parse_constraint(constraint: str) -> Dict[str, str]:
    """Parse a constraint string of the form 'key=value;key2=value2' into a dict."""
    result = {}
    if not constraint:
        return result
    for part in str(constraint).split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        k, v = part.split("=", 1)
        result[k.strip()] = v.strip()
    return result


# Default uniqueness store: in-memory, scope "batch" (per running process).
# For "database" scope, replace UNIQUE_CHECKER with a function that queries
# the real database instead.
_BATCH_UNIQUE_STORE: Dict[Tuple[str, str], set] = {}


def _default_unique_checker(rule_id: str, field_name: str, value: Any, reference_source: str) -> bool:
    """
    Return True if value is UNIQUE (never seen before), False if it's a
    duplicate. Default: "batch" scope -> stored in-memory for the lifetime
    of the current process.
    """
    key = (rule_id, field_name)
    seen = _BATCH_UNIQUE_STORE.setdefault(key, set())
    if value in seen:
        return False
    seen.add(value)
    return True


UNIQUE_CHECKER: Callable[[str, str, Any, str], bool] = _default_unique_checker


def set_unique_checker(func: Callable[[str, str, Any, str], bool]) -> None:
    """
    Override how uniqueness is checked, e.g. to query a SQL Server database
    instead of using the in-memory set. Signature:
        func(rule_id: str, field_name: str, value: Any, reference_source: str) -> bool
    Return True if the value is unique, False if it already exists.
    """
    global UNIQUE_CHECKER
    UNIQUE_CHECKER = func


def reset_batch_unique_store() -> None:
    """Clear the in-memory uniqueness store (e.g. before starting a new batch)."""
    _BATCH_UNIQUE_STORE.clear()


def _check_data_type(
    value: Any,
    data_type: str,
    constraint: str,
    field_name: str,
    rule_id: str,
    reference_source: str,
) -> Tuple[bool, str]:
    data_type = (data_type or "").strip()

    if data_type == "Exist":
        ok = value not in (None, "", [], {})
        return ok, "" if ok else "field is empty or missing"

    if data_type == "Text":
        if not isinstance(value, str) or value == "":
            return False, "must be a non-empty text value"
        params = _parse_constraint(constraint)
        if params.get("pattern") == "alpha_only" and not value.isalpha():
            return False, "must contain letters only"
        return True, ""

    if data_type == "Number":
        params = _parse_constraint(constraint)
        num_type = params.get("type", "float")
        try:
            num = int(value) if num_type == "int" else float(value)
        except (TypeError, ValueError):
            return False, f"must be a number ({num_type})"
        if "min" in params and num < float(params["min"]):
            return False, f"value below minimum ({params['min']})"
        if "max" in params and num > float(params["max"]):
            return False, f"value above maximum ({params['max']})"
        return True, ""

    if data_type == "Boolean":
        truthy = {"true", "y", "yes", "1", True, 1}
        falsy = {"false", "n", "no", "0", False, 0}
        normalized = value.strip().lower() if isinstance(value, str) else value
        if normalized in truthy or normalized in falsy:
            return True, ""
        return False, "must be a boolean value (true/false/Y/N)"

    if data_type == "Date":
        params = _parse_constraint(constraint)
        fmt = params.get("format", "%Y-%m-%d")
        try:
            datetime.strptime(str(value), fmt)
            return True, ""
        except (TypeError, ValueError):
            return False, f"date format must be '{fmt}'"

    if data_type == "Enum":
        allowed = [v.strip() for v in str(constraint).split(",") if v.strip()]
        if str(value) in allowed:
            return True, ""
        return False, f"must be one of: {', '.join(allowed)}"

    if data_type == "Regex":
        if value is not None and re.match(str(constraint), str(value)):
            return True, ""
        return False, f"does not match format '{constraint}'"

    if data_type == "Romanize":
        try:
            str(value).encode("ascii")
            return True, ""
        except (UnicodeEncodeError, AttributeError):
            return False, "contains non-Latin/non-ASCII characters"

    if data_type == "Length":
        params = _parse_constraint(constraint)
        length = len(str(value)) if value is not None else 0
        if "min" in params and length < int(params["min"]):
            return False, f"length must be at least {params['min']} characters"
        if "max" in params and length > int(params["max"]):
            return False, f"length must be at most {params['max']} characters"
        return True, ""

    if data_type == "Unique":
        is_unique = UNIQUE_CHECKER(rule_id, field_name, value, reference_source)
        return (True, "") if is_unique else (False, "duplicate value, already exists")

    raise ValueError(f"Unknown Data Type: '{data_type}'")


# =============================================================================
# ENGINE
# =============================================================================

def _get_conditions(rule_id: str) -> List[Dict[str, Any]]:
    return [c for c in RULE_CONDITIONS_TABLE if c["Rule ID"] == rule_id]


def _triggers_satisfied(record: dict, conditions: List[Dict[str, Any]]) -> bool:
    triggers = [c for c in conditions if c["Role"] == "Trigger"]
    if not triggers:
        return True  # no trigger -> the rule always applies

    logic = (triggers[0].get("Logical Group") or "AND").strip().upper()
    checks = [
        _evaluate_operator(record.get(t["Field Name"]), t["Operator"], t["Expected Value"])
        for t in triggers
    ]
    return any(checks) if logic == "OR" else all(checks)


def _run_rule(rule: Dict[str, Any], record: dict) -> Optional[Dict[str, Any]]:
    """Run 1 rule against 1 record. Returns None if it passes, an exception dict if it fails."""
    if str(rule.get("Active", "Y")).strip().upper() != "Y":
        return None

    rule_id = rule["Rule ID"]
    conditions = _get_conditions(rule_id)
    function_name = str(rule.get("Function Name") or "").strip()

    # --- Rule using a custom Function Name ---
    if function_name:
        func = CUSTOM_VALIDATION_REGISTRY.get(function_name)
        if func is None:
            return {
                "rule_id": rule_id,
                "validation_type": rule["Validation Type"],
                "status": rule.get("On Exception Status"),
                "description": f"Function '{function_name}' is not registered",
                "failed_fields": [],
            }
        target_fields = [c["Field Name"] for c in conditions if c["Role"] == "Target"]
        passed, failed_fields, message = func(record, target_fields, rule)
        if passed:
            return None
        return {
            "rule_id": rule_id,
            "validation_type": rule["Validation Type"],
            "status": rule.get("On Exception Status"),
            "description": rule.get("On Exception Description") or message,
            "failed_fields": failed_fields,
        }

    # --- Generic rule (Trigger/Target from the table, no code needed) ---
    if not _triggers_satisfied(record, conditions):
        return None  # trigger not met -> the rule does not apply to this record

    failed_fields = []
    for target in [c for c in conditions if c["Role"] == "Target"]:
        field_name = target["Field Name"]
        ok, _msg = _check_data_type(
            value=record.get(field_name),
            data_type=target["Data Type"],
            constraint=target.get("Constraint", ""),
            field_name=field_name,
            rule_id=rule_id,
            reference_source=target.get("Reference Source", ""),
        )
        if not ok:
            failed_fields.append(field_name)

    if not failed_fields:
        return None

    return {
        "rule_id": rule_id,
        "validation_type": rule["Validation Type"],
        "status": rule.get("On Exception Status"),
        "description": rule.get("On Exception Description"),
        "failed_fields": failed_fields,
    }


def Validation(id: int, entity_hash: str, entity_result: dict) -> Dict[str, Any]:
    """
    Main entry point. Runs every active rule in RULES_TABLE against
    entity_result and returns a summary of the validation results.

    Parameters
    ----------
    id : int
        The ID of the record being validated.
    entity_hash : str
        A unique hash for this record.
    entity_result : dict
        The data being validated (e.g. a parsed JSON payload).

    Returns
    -------
    dict shaped as:
        {
            "id": ...,
            "entity_hash": ...,
            "is_valid": bool,
            "exceptions": [
                {
                    "rule_id": "VAL-001",
                    "validation_type": "...",
                    "status": -1,
                    "description": "Missing EoID/FiD",
                    "failed_fields": ["EOID"],
                },
                ...
            ],
        }
    """
    exceptions = []
    for rule in RULES_TABLE:
        exc = _run_rule(rule, entity_result)
        if exc is not None:
            exceptions.append(exc)

    return {
        "id": id,
        "entity_hash": entity_hash,
        "is_valid": len(exceptions) == 0,
        "exceptions": exceptions,
    }


# =============================================================================
# OPTIONAL: load RULES_TABLE / RULE_CONDITIONS_TABLE from a SQLite database
# =============================================================================
# Use this if you'd rather keep the rules and rule_conditions data in the
# database created/seeded by the db_setup package instead of hardcoding them
# above. Call this once (e.g. at application startup) before calling
# Validation().

def load_rules_from_database(db_path: str) -> None:
    """
    Replace the in-memory RULES_TABLE and RULE_CONDITIONS_TABLE with the
    contents of the 'rules' and 'rule_conditions' tables in the given
    SQLite database file.
    """
    global RULES_TABLE, RULE_CONDITIONS_TABLE

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rules_rows = conn.execute("SELECT * FROM rules").fetchall()
        RULES_TABLE = [
            {
                "Rule ID": r["rule_id"],
                "Validation Type": r["validation_type"],
                "Function Name": r["function_name"] or "",
                "Description": r["description"],
                "Severity": r["severity"],
                "Active": r["active"],
                "On Exception Status": r["exception_status"],
                "On Exception Description": r["exception_description"],
            }
            for r in rules_rows
        ]

        condition_rows = conn.execute("SELECT * FROM rule_conditions").fetchall()
        RULE_CONDITIONS_TABLE = [
            {
                "Rule ID": c["rule_id"],
                "Role": c["role"],
                "Field Name": c["field_name"],
                "Operator": c["operator"] or "",
                "Expected Value": c["expected_value"] or "",
                "Data Type": c["data_type"] or "",
                "Constraint": c["constraint_value"] or "",
                "Reference Source": c["reference_source"] or "",
                "Logical Group": c["logical_group"] or "",
            }
            for c in condition_rows
        ]
    finally:
        conn.close()
