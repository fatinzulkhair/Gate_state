"""
=====================================================
SEED DATA LAYER
=====================================================
Inserts the initial (default) validation rules and rule
conditions into the database. Safe to run multiple
times: existing rows are replaced rather than duplicated.
"""
from .database import get_connection, initialize_database

# (rule_id, validation_type, function_name, description, severity, active,
#  exception_status, exception_description)
INITIAL_RULES = [
    (
        "VAL-001",
        "Location Master Data – EoId, FID",
        "EoIDFiDValidation",
        "If the location address is in the EU/UK country, then this is a "
        "mandatory OR if the location would produce for EU/UK Market, then "
        "also it is mandatory for this fields to be present",
        "Critical",
        "Y",
        -1,
        "Missing EoID/FiD",
    ),
    (
        "VAL-002",
        "Conditional Field – ACDC UK mapping",
        None,
        "UKEOID/UKFID are mandatory when systemCode = ACDC",
        "Critical",
        "Y",
        -1,
        "Missing UKEOID/UKFID for ACDC",
    ),
    (
        "VAL-003",
        "SGLN Format Check",
        None,
        "SGLN must follow the format urn:epc:id:sgln:...",
        "Critical",
        "Y",
        -1,
        "SGLN format invalid",
    ),
    (
        "VAL-004",
        "System Code Presence",
        None,
        "systemCode is mandatory for every record",
        "Critical",
        "Y",
        -1,
        "Missing systemCode",
    ),
    (
        "VAL-005",
        "EOID Uniqueness",
        None,
        "EOID must not duplicate another already-processed record",
        "Critical",
        "Y",
        -1,
        "Duplicate EOID",
    ),
]

# (rule_id, role, field_name, operator, expected_value, data_type,
#  constraint_value, reference_source, logical_group)
INITIAL_RULE_CONDITIONS = [
    ("VAL-001", "Target", "EOID", None, None, "Exist", None, None, None),
    ("VAL-001", "Target", "FID", None, None, "Exist", None, None, None),

    ("VAL-002", "Trigger", "systemCode", "equals", "ACDC", None, None, None, "AND"),
    ("VAL-002", "Target", "UKEOID", None, None, "Exist", None, None, None),
    ("VAL-002", "Target", "UKFID", None, None, "Exist", None, None, None),

    ("VAL-003", "Target", "SGLN", None, None, "Regex", r"^urn:epc:id:sgln:.+$", None, None),

    ("VAL-004", "Target", "systemCode", None, None, "Exist", None, None, None),

    ("VAL-005", "Target", "EOID", None, None, "Unique", None, "batch", None),
]


def insert_initial_rules() -> None:
    """Insert (or refresh) the default rule set. Idempotent: safe to re-run."""
    conn = get_connection()
    try:
        conn.executemany(
            """
            INSERT INTO rules
                (rule_id, validation_type, function_name, description,
                 severity, active, exception_status, exception_description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(rule_id) DO UPDATE SET
                validation_type = excluded.validation_type,
                function_name = excluded.function_name,
                description = excluded.description,
                severity = excluded.severity,
                active = excluded.active,
                exception_status = excluded.exception_status,
                exception_description = excluded.exception_description
            """,
            INITIAL_RULES,
        )

        # Clear existing conditions for these rule_ids first, then re-insert,
        # so re-running this script never creates duplicate condition rows.
        rule_ids = [r[0] for r in INITIAL_RULES]
        conn.executemany(
            "DELETE FROM rule_conditions WHERE rule_id = ?",
            [(rid,) for rid in rule_ids],
        )
        conn.executemany(
            """
            INSERT INTO rule_conditions
                (rule_id, role, field_name, operator, expected_value,
                 data_type, constraint_value, reference_source, logical_group)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            INITIAL_RULE_CONDITIONS,
        )
        conn.commit()
    finally:
        conn.close()


def setup() -> None:
    """Convenience entry point: create the tables, then seed the initial data."""
    initialize_database()
    insert_initial_rules()


if __name__ == "__main__":
    setup()
    print("Rule tables created and seeded successfully.")
