"""
=====================================================
DATABASE LAYER
=====================================================
Solely responsible for the SQLite connection and table
schema creation for the validation RULES and RULE
CONDITIONS tables. Other modules should never call
sqlite3.connect() directly, just use get_connection().
"""
import sqlite3

from .config import DB_NAME


def get_connection() -> sqlite3.Connection:
    """Open a new connection to the SQLite database."""
    return sqlite3.connect(DB_NAME)


def initialize_database() -> None:
    """Create the 'rules' and 'rule_conditions' tables if they don't exist yet."""
    conn = get_connection()
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS rules (
                rule_id TEXT PRIMARY KEY,
                validation_type TEXT NOT NULL,
                function_name TEXT,
                description TEXT,
                severity TEXT,
                active TEXT DEFAULT 'Y',
                exception_status INTEGER,
                exception_description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );

            CREATE TABLE IF NOT EXISTS rule_conditions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                rule_id TEXT NOT NULL,
                role TEXT NOT NULL,
                field_name TEXT NOT NULL,
                operator TEXT,
                expected_value TEXT,
                data_type TEXT,
                constraint_value TEXT,
                reference_source TEXT,
                logical_group TEXT,
                FOREIGN KEY (rule_id) REFERENCES rules(rule_id)
                );
            """
        )
        conn.commit()
    finally:
        conn.close()
