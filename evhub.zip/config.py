"""
=====================================================
CONFIGURATION
=====================================================
Central place for configuration constants used by the
rule database layer.
"""

DB_NAME = "validation_rules.db"
